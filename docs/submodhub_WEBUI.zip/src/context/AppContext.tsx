import React, { createContext, useContext, useState, useMemo, useCallback } from 'react';
import {
  User,
  UserRole,
  ModSummary,
  ModVersion,
  ScanReport,
  Submission,
  AuditLog,
  Installation,
  InstalledMod,
  InstallationPlan,
  OperationLog,
  DownloadDescriptor,
} from '../types/submodhub';
import {
  INITIAL_USERS,
  INITIAL_MODS,
  INITIAL_VERSIONS,
  INITIAL_SCAN_REPORTS,
  INITIAL_SUBMISSIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_INSTALLATIONS,
  INITIAL_INSTALLED_MODS,
} from '../data/mockData';

export type NavTab =
  | 'catalog'
  | 'author'
  | 'reviewer'
  | 'admin'
  | 'client'
  | 'states';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  code?: string;
}

interface AppContextType {
  // Navigation & View
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  selectedModId: string | null;
  setSelectedModId: (id: string | null) => void;
  detailModalModId: string | null;
  setDetailModalModId: (id: string | null) => void;

  // Session & Roles
  currentUser: User | null;
  switchRolePersona: (role: 'visitor' | 'author' | 'reviewer' | 'admin') => void;
  loginFlarum: (username: string, password: string) => Promise<boolean>;
  loginGithub: () => Promise<boolean>;
  logout: () => void;
  linkAccount: (provider: 'flarum' | 'github', accountName: string) => void;
  hasRole: (role: UserRole) => boolean;

  // Offline Simulation
  isOffline: boolean;
  setIsOffline: (val: boolean) => void;

  // Catalog Data
  mods: ModSummary[];
  versions: ModVersion[];
  scanReports: Record<string, ScanReport>;
  submissions: Submission[];
  auditLogs: AuditLog[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  categoryFilter: string;
  setCategoryFilter: (c: string) => void;
  platformFilter: string;
  setPlatformFilter: (p: string) => void;
  tagFilter: string;
  setTagFilter: (t: string) => void;

  // Mod Detail Helper
  getModWithVersions: (modId: string) => {
    mod: ModSummary | undefined;
    versions: ModVersion[];
    latestVersion?: ModVersion;
  };
  getDownloadDescriptor: (versionId: string) => DownloadDescriptor;

  // Author Actions
  createModDraft: (data: Partial<ModSummary>) => string;
  updateModDraft: (modId: string, data: Partial<ModSummary>) => void;
  createCandidateVersion: (modId: string, version: string, releaseNotes: string) => string;
  uploadArchiveAndScan: (versionId: string, file: File | { name: string; size: number }) => Promise<string>;
  submitVersionForReview: (versionId: string) => boolean;
  reviseRejectedVersion: (submissionId: string) => string;

  // Reviewer Actions
  approveSubmission: (submissionId: string, reason: string) => void;
  rejectSubmission: (submissionId: string, reason: string) => void;
  publishApprovedVersion: (submissionId: string) => void;

  // Admin Actions
  updateUserRoles: (userId: string, newRoles: UserRole[], reason: string) => void;
  unpublishVersion: (versionId: string, reason: string) => void;

  // Client Simulation (Section 4)
  installations: Installation[];
  activeInstallationId: string;
  setActiveInstallationId: (id: string) => void;
  installedMods: InstalledMod[];
  currentPlan: InstallationPlan | null;
  operations: OperationLog[];
  previewInstallPlan: (modId: string, versionId: string) => InstallationPlan;
  applyPlan: (plan: InstallationPlan) => Promise<void>;
  simulateExternalChange: (filePath: string) => void;
  adoptUnmanagedMod: (modId: string) => void;
  clearCurrentPlan: () => void;

  // Notifications
  toasts: Toast[];
  showToast: (type: Toast['type'], message: string, code?: string) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation
  const [activeTab, setActiveTab] = useState<NavTab>('catalog');
  const [selectedModId, setSelectedModId] = useState<string | null>(null);
  const [detailModalModId, setDetailModalModId] = useState<string | null>(null);

  // Session: Default to Author persona so user can immediately experience workbench, or switch easily
  const [currentUser, setCurrentUser] = useState<User | null>(INITIAL_USERS[0]);

  // Offline cache simulation
  const [isOffline, setIsOffline] = useState(false);

  // Data Store
  const [mods, setMods] = useState<ModSummary[]>(INITIAL_MODS);
  const [versions, setVersions] = useState<ModVersion[]>(INITIAL_VERSIONS);
  const [scanReports, setScanReports] = useState<Record<string, ScanReport>>(INITIAL_SCAN_REPORTS);
  const [submissions, setSubmissions] = useState<Submission[]>(INITIAL_SUBMISSIONS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [platformFilter, setPlatformFilter] = useState('all');
  const [tagFilter, setTagFilter] = useState('all');

  // Client Companion Simulator State
  const [installations, setInstallations] = useState<Installation[]>(INITIAL_INSTALLATIONS);
  const [activeInstallationId, setActiveInstallationId] = useState<string>(INITIAL_INSTALLATIONS[0].id);
  const [installedMods, setInstalledMods] = useState<InstalledMod[]>(INITIAL_INSTALLED_MODS);
  const [currentPlan, setCurrentPlan] = useState<InstallationPlan | null>(null);
  const [operations, setOperations] = useState<OperationLog[]>([]);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((type: Toast['type'], message: string, code?: string) => {
    const id = 'toast_' + Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, message, code }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Quick Persona / Role Switcher
  const switchRolePersona = useCallback((role: 'visitor' | 'author' | 'reviewer' | 'admin') => {
    if (role === 'visitor') {
      setCurrentUser(null);
      showToast('info', '已切换为访客视角 (未登录)，可浏览目录与下载模组。');
    } else if (role === 'author') {
      setCurrentUser(INITIAL_USERS[0]);
      showToast('success', '已切换为【作者】莫妮卡守望者 (Author)。');
    } else if (role === 'reviewer') {
      setCurrentUser(INITIAL_USERS[1]);
      showToast('success', '已切换为【核心审核员】AegisReviewer (Reviewer)。');
    } else if (role === 'admin') {
      setCurrentUser(INITIAL_USERS[2]);
      showToast('success', '已切换为【社区总管理员】RootArchon (Admin)。');
    }
  }, [showToast]);

  const hasRole = useCallback(
    (role: UserRole) => {
      if (!currentUser) return false;
      return currentUser.roles.includes(role);
    },
    [currentUser]
  );

  const loginFlarum = useCallback(
    async (username: string): Promise<boolean> => {
      // Simulate Flarum server-side credential verification
      const newUser: User = {
        id: 'user_' + username.toLowerCase(),
        username,
        display_name: `${username} (Flarum)`,
        roles: ['author'],
        linked_accounts: { flarum: username },
      };
      setCurrentUser(newUser);
      showToast('success', `Flarum 认证成功，建立安全会话：${username}`);
      return true;
    },
    [showToast]
  );

  const loginGithub = useCallback(async (): Promise<boolean> => {
    const githubUser: User = {
      id: 'user_gh_' + Math.floor(Math.random() * 1000),
      username: 'GitHubContributor',
      display_name: 'GitHub 贡献者 (OAuth)',
      roles: ['author', 'reviewer'],
      linked_accounts: { github: 'monika-dev-hub' },
    };
    setCurrentUser(githubUser);
    showToast('success', 'GitHub OAuth (PKCE) 授权成功，已绑定会话。');
    return true;
  }, [showToast]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    showToast('info', '会话已终止 (POST /auth/logout)。');
  }, [showToast]);

  const linkAccount = useCallback(
    (provider: 'flarum' | 'github', accountName: string) => {
      if (!currentUser) {
        showToast('error', '未登录状态无法发起账号关联。', 'unauthenticated');
        return;
      }
      setCurrentUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          linked_accounts: {
            ...prev.linked_accounts,
            [provider]: accountName,
          },
        };
      });
      showToast('success', `成功关联 ${provider === 'github' ? 'GitHub' : 'Flarum'} 账号: ${accountName}`);
    },
    [currentUser, showToast]
  );

  const getModWithVersions = useCallback(
    (modId: string) => {
      const mod = mods.find((m) => m.id === modId);
      const modVersions = versions.filter((v) => v.mod_id === modId);
      const latestVersion = modVersions.find((v) => v.id === mod?.latest_version_id) || modVersions[0];
      return { mod, versions: modVersions, latestVersion };
    },
    [mods, versions]
  );

  const getDownloadDescriptor = useCallback(
    (versionId: string): DownloadDescriptor => {
      const v = versions.find((item) => item.id === versionId);
      const filename = `submod_${v?.mod_id || 'archive'}_v${v?.version || '1.0.0'}.zip`;
      const expires = new Date(Date.now() + 3600 * 1000).toISOString();
      return {
        url: `https://cdn.submodhub.org/v1/archives/${filename}?sig=sha256_${v?.sha256.substring(0, 16)}&exp=${expires}`,
        expires_at: expires,
        sha256: v?.sha256 || '0000000000000000000000000000000000000000000000000000000000000000',
        size_bytes: v?.size_bytes || 1024000,
        filename,
      };
    },
    [versions]
  );

  // Author Actions
  const createModDraft = useCallback(
    (data: Partial<ModSummary>): string => {
      if (!currentUser || !currentUser.roles.includes('author')) {
        showToast('error', '只有作者角色可以创建模组草稿。', 'forbidden');
        return '';
      }
      const newId = 'mod_' + (data.title?.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20) || 'draft_' + Date.now());
      const newMod: ModSummary = {
        id: newId,
        title: data.title || '未命名模组草稿',
        summary: data.summary || '暂无简介描述',
        description: data.description || '## 模组概述\n欢迎使用本模组。',
        author: {
          id: currentUser.id,
          display_name: currentUser.display_name,
        },
        category: data.category || 'submod',
        tags: data.tags || ['dialogue'],
        supported_platforms: data.supported_platforms || ['windows', 'android'],
        mas_version_range: data.mas_version_range || '>=0.12.14',
        recommended_priority: data.recommended_priority || 20,
        latest_version_id: '',
        downloads_count: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_published: false,
      };

      setMods((prev) => [newMod, ...prev]);
      showToast('success', `成功创建模组草稿 [${newMod.title}]`);
      return newId;
    },
    [currentUser, showToast]
  );

  const updateModDraft = useCallback(
    (modId: string, data: Partial<ModSummary>) => {
      setMods((prev) =>
        prev.map((m) => {
          if (m.id === modId) {
            return {
              ...m,
              ...data,
              updated_at: new Date().toISOString(),
            };
          }
          return m;
        })
      );
      showToast('success', '模组元数据与依赖配置已保存 (PATCH /author/mods/{id})');
    },
    [showToast]
  );

  const createCandidateVersion = useCallback(
    (modId: string, version: string, releaseNotes: string): string => {
      const newVersionId = 'ver_' + modId.replace('mod_', '') + '_' + version.replace(/[^a-z0-9]/g, '_');
      const newVer: ModVersion = {
        id: newVersionId,
        mod_id: modId,
        version,
        state: 'draft',
        size_bytes: 0,
        sha256: '',
        release_notes: releaseNotes,
        dependencies: [],
        created_at: new Date().toISOString(),
        is_immutable: false,
      };

      setVersions((prev) => [newVer, ...prev]);
      showToast('success', `候选版本 ${version} 草稿已建立，等待上传 ZIP 归档。`);
      return newVersionId;
    },
    [showToast]
  );

  const uploadArchiveAndScan = useCallback(
    async (versionId: string, file: File | { name: string; size: number }): Promise<string> => {
      const reportId = 'scan_' + versionId;

      // Update version to uploaded -> scanning
      setVersions((prev) =>
        prev.map((v) => (v.id === versionId ? { ...v, state: 'scanning', size_bytes: file.size } : v))
      );

      // Generate random simulated SHA256
      const randomHex = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

      // Create detailed ScanReport
      const isUnsafeTest = file.name.toLowerCase().includes('unsafe') || file.name.toLowerCase().includes('hack');
      const hasSpritepack = file.name.toLowerCase().includes('sprite') || file.name.toLowerCase().includes('clothes');

      const newScanReport: ScanReport = {
        id: reportId,
        version_id: versionId,
        status: isUnsafeTest ? 'ready' : 'ready',
        files: [
          {
            source_path: `game/Submods/${versionId}/main.rpy`,
            target_path: `game/Submods/${versionId}/main.rpy`,
            size_bytes: Math.floor(file.size * 0.4),
            sha256: randomHex.substring(0, 64),
            kind: 'script',
          },
          {
            source_path: `game/Submods/${versionId}/assets/preview.png`,
            target_path: `game/Submods/${versionId}/assets/preview.png`,
            size_bytes: Math.floor(file.size * 0.6),
            sha256: randomHex.substring(10, 64) + 'abcd1234',
            kind: hasSpritepack ? 'sprite' : 'audio',
          },
        ],
        unsupported_paths: isUnsafeTest ? ['autorun.bat'] : [],
        registrations: [
          {
            submod_id: versionId,
            name: `Submod ${versionId}`,
            version: '1.0.0',
            author: currentUser?.display_name || 'Author',
            confidence: isUnsafeTest ? 'unknown' : 'known', // Unknown static parsing results must NOT be shown as safe!
          },
        ],
        sprite_identities: hasSpritepack
          ? [
              {
                category: 'clothes',
                name: 'custom_outfit',
                giftname: 'gift_custom_outfit_daily',
                poses: ['def', 'sitting'],
              },
            ]
          : [],
        derived_gifts: hasSpritepack ? ['gift_custom_outfit_daily'] : [],
        blockers: isUnsafeTest
          ? ['静态扫描阻断：检测到外部注入批处理脚本 [autorun.bat]', '未知静态签名 (confidence: unknown)']
          : [],
        warnings: hasSpritepack
          ? ['检测到 Spritepack 礼物注册，请确保未与既有礼物重名。']
          : [],
        resource_stats: {
          total_files: 2,
          scripts_count: 1,
          sprites_count: hasSpritepack ? 1 : 0,
          audio_count: hasSpritepack ? 0 : 1,
          total_size_bytes: file.size,
          binary_flag: isUnsafeTest,
        },
        scanned_at: new Date().toISOString(),
      };

      setScanReports((prev) => ({
        ...prev,
        [reportId]: newScanReport,
      }));

      setVersions((prev) =>
        prev.map((v) =>
          v.id === versionId
            ? {
                ...v,
                state: 'uploaded',
                sha256: randomHex,
                scan_report_id: reportId,
              }
            : v
        )
      );

      showToast('success', `ZIP 归档上传成功并已完成静态扫描报告生成 (SHA-256: ${randomHex.slice(0, 12)}...)`);
      return reportId;
    },
    [currentUser, showToast]
  );

  const submitVersionForReview = useCallback(
    (versionId: string): boolean => {
      const v = versions.find((item) => item.id === versionId);
      if (!v) return false;

      const report = v.scan_report_id ? scanReports[v.scan_report_id] : null;
      if (report && report.blockers.length > 0) {
        showToast('error', `无法提交审核：存在 ${report.blockers.length} 个扫描阻断项，请先修正问题包。`, 'validation_failed');
        return false;
      }

      const mod = mods.find((m) => m.id === v.mod_id);
      const submissionId = 'sub_' + Math.random().toString(36).substring(2, 9);

      const newSubmission: Submission = {
        id: submissionId,
        mod_id: v.mod_id,
        version_id: v.id,
        mod_title: mod?.title || v.mod_id,
        version_str: v.version,
        category: mod?.category || 'submod',
        author_id: currentUser?.id || 'unknown_author',
        author_name: currentUser?.display_name || '作者',
        submitted_at: new Date().toISOString(),
        state: 'ready_for_review',
      };

      setSubmissions((prev) => [newSubmission, ...prev]);
      setVersions((prev) =>
        prev.map((item) => (item.id === versionId ? { ...item, state: 'ready_for_review' } : item))
      );

      showToast('success', `候选版本 ${v.version} 已进入审核队列 (POST /author/versions/{id}/submit)`);
      return true;
    },
    [versions, scanReports, mods, currentUser, showToast]
  );

  const reviseRejectedVersion = useCallback(
    (submissionId: string): string => {
      const sub = submissions.find((s) => s.id === submissionId);
      if (!sub) return '';
      const oldVer = versions.find((v) => v.id === sub.version_id);
      if (!oldVer) return '';

      const revisedVerStr = oldVer.version + '-revised';
      const newVersionId = 'ver_' + sub.mod_id + '_' + Date.now();

      const newVer: ModVersion = {
        id: newVersionId,
        mod_id: sub.mod_id,
        version: revisedVerStr,
        state: 'draft',
        size_bytes: 0,
        sha256: '',
        release_notes: `[根据驳回反馈修订]: 前次审核意见: "${sub.decision_reason || '修正阻断文件'}". ` + oldVer.release_notes,
        dependencies: oldVer.dependencies,
        created_at: new Date().toISOString(),
        is_immutable: false,
      };

      setVersions((prev) => [newVer, ...prev]);
      showToast('info', `已基于被驳回版本克隆创建修订候选草稿 ${revisedVerStr}，请重新打包上传 ZIP。`);
      return newVersionId;
    },
    [submissions, versions, showToast]
  );

  // Reviewer Actions
  const approveSubmission = useCallback(
    (submissionId: string, reason: string) => {
      if (!currentUser || !currentUser.roles.includes('reviewer')) {
        showToast('error', '缺少审核员权限 (reviewer)。', 'forbidden');
        return;
      }

      setSubmissions((prev) =>
        prev.map((s) =>
          s.id === submissionId
            ? {
                ...s,
                state: 'approved',
                reviewer_id: currentUser.id,
                reviewer_name: currentUser.display_name,
                decision_reason: reason,
                decided_at: new Date().toISOString(),
              }
            : s
        )
      );

      const sub = submissions.find((s) => s.id === submissionId);
      if (sub) {
        setVersions((prev) =>
          prev.map((v) => (v.id === sub.version_id ? { ...v, state: 'approved' } : v))
        );

        // Record Audit Log
        const auditItem: AuditLog = {
          id: 'audit_' + Date.now(),
          timestamp: new Date().toISOString(),
          actor_id: currentUser.id,
          actor_name: currentUser.display_name,
          actor_role: 'reviewer',
          action: 'submission_approve',
          target_type: 'submission',
          target_id: sub.id,
          target_label: `${sub.mod_title} (${sub.version_str}) 审核批准`,
          reason,
        };
        setAuditLogs((prev) => [auditItem, ...prev]);
      }

      showToast('success', '版本审核通过已批准！根据契约规范，发布为独立可审计步骤，可继续点击发布。');
    },
    [currentUser, submissions, showToast]
  );

  const rejectSubmission = useCallback(
    (submissionId: string, reason: string) => {
      if (!currentUser || !currentUser.roles.includes('reviewer')) {
        showToast('error', '缺少审核员权限 (reviewer)。', 'forbidden');
        return;
      }
      if (!reason.trim()) {
        showToast('error', '驳回必须填写具体的安全或规范理由。', 'validation_failed');
        return;
      }

      setSubmissions((prev) =>
        prev.map((s) =>
          s.id === submissionId
            ? {
                ...s,
                state: 'rejected',
                reviewer_id: currentUser.id,
                reviewer_name: currentUser.display_name,
                decision_reason: reason,
                decided_at: new Date().toISOString(),
              }
            : s
        )
      );

      const sub = submissions.find((s) => s.id === submissionId);
      if (sub) {
        setVersions((prev) =>
          prev.map((v) => (v.id === sub.version_id ? { ...v, state: 'rejected' } : v))
        );

        // Record Audit Log
        const auditItem: AuditLog = {
          id: 'audit_' + Date.now(),
          timestamp: new Date().toISOString(),
          actor_id: currentUser.id,
          actor_name: currentUser.display_name,
          actor_role: 'reviewer',
          action: 'submission_reject',
          target_type: 'submission',
          target_id: sub.id,
          target_label: `${sub.mod_title} (${sub.version_str}) 审核驳回`,
          reason,
        };
        setAuditLogs((prev) => [auditItem, ...prev]);
      }

      showToast('warning', `已驳回申请，作者将能在工作台查阅驳回理由并进行版本修订。`);
    },
    [currentUser, submissions, showToast]
  );

  const publishApprovedVersion = useCallback(
    (submissionId: string) => {
      const sub = submissions.find((s) => s.id === submissionId);
      if (!sub) return;

      const v = versions.find((item) => item.id === sub.version_id);
      if (!v) return;

      const now = new Date().toISOString();

      // Mark version as published & immutable
      setVersions((prev) =>
        prev.map((item) =>
          item.id === v.id
            ? {
                ...item,
                state: 'published',
                published_at: now,
                is_immutable: true,
              }
            : item
        )
      );

      // Update Mod latest_version_id and published status
      setMods((prev) =>
        prev.map((m) =>
          m.id === sub.mod_id
            ? {
                ...m,
                latest_version_id: v.id,
                is_published: true,
                updated_at: now,
              }
            : m
        )
      );

      // Update submission state
      setSubmissions((prev) =>
        prev.map((s) =>
          s.id === submissionId ? { ...s, state: 'published', published_at: now } : s
        )
      );

      // Audit Log
      const auditItem: AuditLog = {
        id: 'audit_' + Date.now(),
        timestamp: now,
        actor_id: currentUser?.id || 'sys',
        actor_name: currentUser?.display_name || '系统',
        actor_role: 'reviewer',
        action: 'version_publish',
        target_type: 'version',
        target_id: v.id,
        target_label: `${sub.mod_title} (${v.version}) 正式发布`,
        reason: '发布不可变版本，对外公开分发并更新目录索引',
        details: { sha256: v.sha256, size_bytes: v.size_bytes },
      };
      setAuditLogs((prev) => [auditItem, ...prev]);

      showToast('success', `不可变版本 ${v.version} 发布成功！已上线公开目录 (POST /review/submissions/{id}/publish)`);
    },
    [submissions, versions, currentUser, showToast]
  );

  // Admin Actions
  const updateUserRoles = useCallback(
    (userId: string, newRoles: UserRole[], reason: string) => {
      if (!currentUser || !currentUser.roles.includes('admin')) {
        showToast('error', '缺少管理员权限 (admin)。', 'forbidden');
        return;
      }

      // Record Audit
      const auditItem: AuditLog = {
        id: 'audit_' + Date.now(),
        timestamp: new Date().toISOString(),
        actor_id: currentUser.id,
        actor_name: currentUser.display_name,
        actor_role: 'admin',
        action: 'role_grant',
        target_type: 'user',
        target_id: userId,
        target_label: `用户 ${userId} 角色变更为 [${newRoles.join(', ')}]`,
        reason,
      };
      setAuditLogs((prev) => [auditItem, ...prev]);
      showToast('success', `用户角色已更新并在系统审计流中留痕。`);
    },
    [currentUser, showToast]
  );

  const unpublishVersion = useCallback(
    (versionId: string, reason: string) => {
      if (!currentUser || !currentUser.roles.includes('admin')) {
        showToast('error', '缺少管理员权限 (admin)。', 'forbidden');
        return;
      }
      if (!reason.trim()) {
        showToast('error', '下架操作必须记录审计理由。', 'validation_failed');
        return;
      }

      setVersions((prev) =>
        prev.map((v) =>
          v.id === versionId ? { ...v, state: 'unpublished', unpublish_reason: reason } : v
        )
      );

      const targetVer = versions.find((v) => v.id === versionId);
      const auditItem: AuditLog = {
        id: 'audit_' + Date.now(),
        timestamp: new Date().toISOString(),
        actor_id: currentUser.id,
        actor_name: currentUser.display_name,
        actor_role: 'admin',
        action: 'version_unpublish',
        target_type: 'version',
        target_id: versionId,
        target_label: `版本 ${targetVer?.version || versionId} 紧急下架`,
        reason,
      };
      setAuditLogs((prev) => [auditItem, ...prev]);

      showToast('warning', `该版本已被安全下架（不可变归档字节保留在后端，公开目录已隐藏）。`);
    },
    [currentUser, versions, showToast]
  );

  // Client Simulation Methods (Section 4)
  const previewInstallPlan = useCallback(
    (modId: string, versionId: string): InstallationPlan => {
      const mod = mods.find((m) => m.id === modId);
      const v = versions.find((item) => item.id === versionId);
      const inst = installations.find((i) => i.id === activeInstallationId);

      const dependencyBlockers: string[] = [];
      const semanticBlockers: string[] = [];
      const warnings: string[] = [];

      // Check MAS version range
      if (inst && mod?.mas_version_range) {
        if (inst.mas_version === '0.12.10' && mod.mas_version_range.includes('0.12.14')) {
          dependencyBlockers.push(
            `MAS 版本不满足要求：当前游戏版本为 ${inst.mas_version}，模组需要 ${mod.mas_version_range}`
          );
        }
      }

      // Check required dependencies
      if (v?.dependencies && v.dependencies.length > 0) {
        for (const dep of v.dependencies) {
          if (dep.required) {
            const isInstalled = installedMods.some((im) => im.mod_id === dep.mod_id);
            if (!isInstalled) {
              dependencyBlockers.push(`缺少必需前置模组 [${dep.mod_title || dep.mod_id}] (${dep.version_range})`);
            }
          }
        }
      }

      // Check Spritepack giftname semantic conflicts
      const report = v?.scan_report_id ? scanReports[v.scan_report_id] : null;
      if (report && report.derived_gifts.length > 0) {
        // check if already installed spritepack has duplicate
        if (installedMods.some((im) => im.mod_id === 'mod_emerald_blossoms') && modId !== 'mod_emerald_blossoms') {
          // simulation check
        }
      }

      const plan: InstallationPlan = {
        plan_id: 'plan_' + Math.random().toString(36).substring(2, 9),
        kind: 'install',
        installation_id: activeInstallationId,
        mod_id: modId,
        version_id: versionId,
        expires_at: new Date(Date.now() + 600 * 1000).toISOString(),
        dependency_blockers: dependencyBlockers,
        semantic_blockers: semanticBlockers,
        changes: [
          {
            target_path: `game/Submods/${mod?.id || 'Mod'}/core.rpy`,
            action: 'create',
            next_owner: modId,
            reason: '新增模组主入口脚本',
          },
          {
            target_path: `game/Submods/${mod?.id || 'Mod'}/assets/pack.png`,
            action: 'create',
            next_owner: modId,
            reason: '新增材质资源包',
          },
        ],
        backups_required: [`game/Submods/${mod?.id || 'Mod'}/backup_manifest.json`],
        bytes_required: v?.size_bytes || 5242880,
        warnings,
        is_ready_to_apply: dependencyBlockers.length === 0 && semanticBlockers.length === 0,
      };

      setCurrentPlan(plan);
      return plan;
    },
    [mods, versions, installations, activeInstallationId, installedMods, scanReports]
  );

  const applyPlan = useCallback(
    async (plan: InstallationPlan) => {
      if (!plan.is_ready_to_apply) {
        showToast('error', '存在未解决的依赖阻断或语义冲突，无法执行安装。', 'dependency_missing');
        return;
      }

      const opId = 'op_' + Math.random().toString(36).substring(2, 9);
      const mod = mods.find((m) => m.id === plan.mod_id);
      const v = versions.find((item) => item.id === plan.version_id);

      const newOp: OperationLog = {
        operation_id: opId,
        installation_id: plan.installation_id,
        mod_title: mod?.title || plan.mod_id,
        version: v?.version || '1.0.0',
        state: 'downloading',
        progress_percent: 15,
        current_file: '正在拉取加密归档描述符...',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      setOperations((prev) => [newOp, ...prev]);

      // Step 1: downloading -> scanning
      await new Promise((res) => setTimeout(res, 600));
      setOperations((prev) =>
        prev.map((o) =>
          o.operation_id === opId
            ? { ...o, state: 'scanning', progress_percent: 45, current_file: '静态文件树与校验和验证中...' }
            : o
        )
      );

      // Step 2: backed_up
      await new Promise((res) => setTimeout(res, 600));
      setOperations((prev) =>
        prev.map((o) =>
          o.operation_id === opId
            ? { ...o, state: 'backed_up', progress_percent: 70, current_file: '生成覆盖层快照与备份清单...' }
            : o
        )
      );

      // Step 3: writing
      await new Promise((res) => setTimeout(res, 600));
      setOperations((prev) =>
        prev.map((o) =>
          o.operation_id === opId
            ? { ...o, state: 'writing', progress_percent: 90, current_file: '写入目标文件并应用权限...' }
            : o
        )
      );

      // Step 4: committed
      await new Promise((res) => setTimeout(res, 500));
      setOperations((prev) =>
        prev.map((o) =>
          o.operation_id === opId
            ? { ...o, state: 'committed', progress_percent: 100, current_file: '写入完成，状态已提交。' }
            : o
        )
      );

      // Add to installedMods
      setInstalledMods((prev) => [
        {
          id: 'im_' + Date.now(),
          mod_id: plan.mod_id,
          title: mod?.title || plan.mod_id,
          version: v?.version || '1.0.0',
          category: mod?.category || 'submod',
          is_managed: true,
          priority: mod?.recommended_priority || 20,
          installed_at: new Date().toISOString(),
        },
        ...prev.filter((item) => item.mod_id !== plan.mod_id),
      ]);

      setCurrentPlan(null);
      showToast('success', `模组 [${mod?.title}] 安装成功并已提交事务！`);
    },
    [mods, versions, showToast]
  );

  const simulateExternalChange = useCallback(
    (filePath: string) => {
      const opId = 'op_drift_' + Math.random().toString(36).substring(2, 7);
      const newOp: OperationLog = {
        operation_id: opId,
        installation_id: activeInstallationId,
        mod_title: 'Extra Everything (更新验证)',
        version: '1.3.0',
        state: 'blocked',
        progress_percent: 65,
        current_file: filePath,
        error_code: 'external_change',
        error_message: '文件哈希外部漂移：目标路径存在外部非托管手动改动，禁止静默覆盖！',
        external_change_details: {
          path: filePath,
          expected_hash: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
          actual_hash: '44aa88220011ccff8899aabbccddeeff11223344556677889900aabbccddeeff (本地外部修改)',
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      setOperations((prev) => [newOp, ...prev]);
      showToast(
        'error',
        '触发 external_change 安全护栏：文件哈希漂移已暂停写入，保护用户未备份的手动修改！',
        'external_change'
      );
    },
    [activeInstallationId, showToast]
  );

  const adoptUnmanagedMod = useCallback(
    (modId: string) => {
      setInstalledMods((prev) =>
        prev.map((m) => (m.mod_id === modId ? { ...m, is_managed: true, version: '1.0.0 (已收养托管)' } : m))
      );
      showToast('success', '未托管脚本已完成显式收养，纳入 SubmodHub 版本管理与恢复树！');
    },
    [showToast]
  );

  const clearCurrentPlan = useCallback(() => {
    setCurrentPlan(null);
  }, []);

  const value = useMemo(
    () => ({
      activeTab,
      setActiveTab,
      selectedModId,
      setSelectedModId,
      detailModalModId,
      setDetailModalModId,
      currentUser,
      switchRolePersona,
      loginFlarum,
      loginGithub,
      logout,
      linkAccount,
      hasRole,
      isOffline,
      setIsOffline,
      mods,
      versions,
      scanReports,
      submissions,
      auditLogs,
      searchQuery,
      setSearchQuery,
      categoryFilter,
      setCategoryFilter,
      platformFilter,
      setPlatformFilter,
      tagFilter,
      setTagFilter,
      getModWithVersions,
      getDownloadDescriptor,
      createModDraft,
      updateModDraft,
      createCandidateVersion,
      uploadArchiveAndScan,
      submitVersionForReview,
      reviseRejectedVersion,
      approveSubmission,
      rejectSubmission,
      publishApprovedVersion,
      updateUserRoles,
      unpublishVersion,
      installations,
      activeInstallationId,
      setActiveInstallationId,
      installedMods,
      currentPlan,
      operations,
      previewInstallPlan,
      applyPlan,
      simulateExternalChange,
      adoptUnmanagedMod,
      clearCurrentPlan,
      toasts,
      showToast,
      removeToast,
    }),
    [
      activeTab,
      selectedModId,
      detailModalModId,
      currentUser,
      switchRolePersona,
      loginFlarum,
      loginGithub,
      logout,
      linkAccount,
      hasRole,
      isOffline,
      mods,
      versions,
      scanReports,
      submissions,
      auditLogs,
      searchQuery,
      categoryFilter,
      platformFilter,
      tagFilter,
      getModWithVersions,
      getDownloadDescriptor,
      createModDraft,
      updateModDraft,
      createCandidateVersion,
      uploadArchiveAndScan,
      submitVersionForReview,
      reviseRejectedVersion,
      approveSubmission,
      rejectSubmission,
      publishApprovedVersion,
      updateUserRoles,
      unpublishVersion,
      installations,
      activeInstallationId,
      installedMods,
      currentPlan,
      operations,
      previewInstallPlan,
      applyPlan,
      simulateExternalChange,
      adoptUnmanagedMod,
      clearCurrentPlan,
      toasts,
      showToast,
      removeToast,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
