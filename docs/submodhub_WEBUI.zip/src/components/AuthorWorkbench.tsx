import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ModCategory, Platform, ModSummary, ScannedFile } from '../types/submodhub';
import {
  Plus,
  Upload,
  FileCheck,
  AlertTriangle,
  AlertCircle,
  FileCode,
  ShieldCheck,
  FolderTree,
  Send,
  GitBranch,
  Github,
  CheckCircle2,
  RefreshCw,
  Clock,
  ExternalLink,
  ChevronRight,
  ChevronDown,
} from 'lucide-react';

export const AuthorWorkbench: React.FC = () => {
  const {
    currentUser,
    hasRole,
    mods,
    versions,
    scanReports,
    submissions,
    createModDraft,
    updateModDraft,
    createCandidateVersion,
    uploadArchiveAndScan,
    submitVersionForReview,
    reviseRejectedVersion,
    showToast,
  } = useApp();

  // Author role check
  const isAuthor = hasRole('author');

  // Active Mod in Workbench
  const userMods = mods.filter(
    (m) => m.author.id === currentUser?.id || currentUser?.roles.includes('author')
  );
  const [selectedModId, setSelectedModId] = useState<string>(() => userMods[0]?.id || '');

  // Mod Draft Creation Dialog
  const [isNewModModalOpen, setIsNewModModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newCategory, setNewCategory] = useState<ModCategory>('submod');
  const [newMasRange, setNewMasRange] = useState('>=0.12.14');
  const [newPriority, setNewPriority] = useState(20);
  const [newTagsStr, setNewTagsStr] = useState('dialogue, dates');
  const [newPlatforms, setNewPlatforms] = useState<Platform[]>(['windows', 'android']);

  // Version Draft Creation Dialog
  const [isNewVersionModalOpen, setIsNewVersionModalOpen] = useState(false);
  const [newVerString, setNewVerString] = useState('1.3.0');
  const [newReleaseNotes, setNewReleaseNotes] = useState('');

  // Upload simulation state
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedVersionForUpload, setSelectedVersionForUpload] = useState<string>('');

  // GitHub Import Dialog
  const [isGithubImportOpen, setIsGithubImportOpen] = useState(false);
  const [githubReleaseUrl, setGithubReleaseUrl] = useState('');

  // Submissions Tab vs Workbench Mod Tab
  const [workbenchView, setWorkbenchView] = useState<'mods' | 'submissions'>('mods');

  // Currently inspected Scan Report modal
  const [inspectingReportId, setInspectingReportId] = useState<string | null>(null);

  const activeMod = mods.find((m) => m.id === selectedModId) || userMods[0];
  const activeModVersions = versions.filter((v) => v.mod_id === activeMod?.id);
  const authorSubmissions = submissions.filter(
    (s) => s.author_id === currentUser?.id || currentUser?.roles.includes('author')
  );

  const handleCreateDraftSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const tags = newTagsStr
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const createdId = createModDraft({
      title: newTitle,
      summary: newSummary,
      category: newCategory,
      mas_version_range: newMasRange,
      recommended_priority: Number(newPriority),
      tags,
      supported_platforms: newPlatforms,
    });

    if (createdId) {
      setSelectedModId(createdId);
      setIsNewModModalOpen(false);
      setNewTitle('');
      setNewSummary('');
    }
  };

  const handleCreateVersionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMod || !newVerString.trim()) return;

    createCandidateVersion(activeMod.id, newVerString.trim(), newReleaseNotes.trim());
    setIsNewVersionModalOpen(false);
    setNewVerString('');
    setNewReleaseNotes('');
  };

  const handleUploadArchiveSim = async (versionId: string, testType?: 'normal' | 'unsafe' | 'sprite') => {
    setIsUploading(true);
    setSelectedVersionForUpload(versionId);
    setUploadProgress(10);

    const stepTimer = setInterval(() => {
      setUploadProgress((p) => {
        if (p >= 90) {
          clearInterval(stepTimer);
          return 90;
        }
        return p + 25;
      });
    }, 200);

    setTimeout(async () => {
      clearInterval(stepTimer);
      setUploadProgress(100);

      const fakeFilename =
        testType === 'unsafe'
          ? 'mod_unsafe_hook_payload.zip'
          : testType === 'sprite'
          ? 'mod_custom_sprite_outfit.zip'
          : `${activeMod?.id || 'mod'}_v1.3.0_release.zip`;

      const reportId = await uploadArchiveAndScan(versionId, {
        name: fakeFilename,
        size: testType === 'unsafe' ? 7890000 : 4892000,
      });

      setIsUploading(false);
      setUploadProgress(0);
      setInspectingReportId(reportId);
    }, 1000);
  };

  const handleGithubImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!githubReleaseUrl.trim()) return;

    showToast('info', '正在解析 GitHub Release Asset 并拉取归档 (POST /author/github-imports)...');

    setTimeout(() => {
      const newModId = createModDraft({
        title: 'GitHub Imported Submod',
        summary: `导入自 ${githubReleaseUrl}，自动转换至候选版本并触发 Aegis 扫描。`,
        category: 'submod',
        tags: ['github-imported', 'dialogue'],
      });
      setSelectedModId(newModId);
      const vId = createCandidateVersion(newModId, '1.0.0-gh', '从 GitHub Release 资产导入。');
      uploadArchiveAndScan(vId, { name: 'github_release_asset.zip', size: 3600000 });
      setIsGithubImportOpen(false);
      setGithubReleaseUrl('');
    }, 800);
  };

  if (!isAuthor) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <AlertCircle className="w-10 h-10 text-neutral-400 mx-auto" />
        <h2 className="text-base font-bold text-neutral-800">未授权访问作者工作台</h2>
        <p className="text-xs text-neutral-500 max-w-md mx-auto">
          作者工作台需要拥有【作者 (Author)】权限。你可以使用顶部导航栏右上角的身份切换器，快速切换为作者角色。
        </p>
      </div>
    );
  }

  const inspectingReport = inspectingReportId ? scanReports[inspectingReportId] : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner & Stats */}
      <div className="bg-white border border-neutral-200 rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <span className="font-semibold text-neutral-900">{currentUser?.display_name}</span>
            <span>·</span>
            <span>作者专属工作区</span>
          </div>
          <h1 className="text-lg font-bold text-neutral-900 tracking-tight mt-0.5">
            模组创作、ZIP 上传与扫描报告管理
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            支持旧式 ZIP 静态解构、Aegis 安全与冲突检测、不可变版本发布提交
          </p>
        </div>

        {/* View Switcher & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-neutral-100 p-0.5 rounded text-xs font-medium mr-2">
            <button
              onClick={() => setWorkbenchView('mods')}
              className={`px-3 py-1.5 rounded transition-colors ${
                workbenchView === 'mods' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-600'
              }`}
            >
              模组与候选版本
            </button>
            <button
              onClick={() => setWorkbenchView('submissions')}
              className={`px-3 py-1.5 rounded transition-colors ${
                workbenchView === 'submissions'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600'
              }`}
            >
              提交历史与修订 ({authorSubmissions.length})
            </button>
          </div>

          <button
            onClick={() => setIsGithubImportOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200/80 rounded transition-colors"
          >
            <Github className="w-3.5 h-3.5 text-neutral-800" />
            GitHub 导入
          </button>

          <button
            onClick={() => setIsNewModModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            新建模组草稿
          </button>
        </div>
      </div>

      {workbenchView === 'submissions' ? (
        /* Submissions & Revision History View */
        <div className="bg-white border border-neutral-200 rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-neutral-900">版本审核提交历史与驳回修订</h2>
              <p className="text-xs text-neutral-500">
                查看各版本的审核流转状态。若被审核员驳回，可查阅详细理由并一键复制创建修订候选。
              </p>
            </div>
            <span className="text-xs font-mono text-neutral-400">
              共 {authorSubmissions.length} 条记录
            </span>
          </div>

          {authorSubmissions.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-400">暂无提交审核记录</div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {authorSubmissions.map((sub) => {
                const subVer = versions.find((v) => v.id === sub.version_id);
                const isRejected = sub.state === 'rejected';
                const isApproved = sub.state === 'approved';
                const isPublished = sub.state === 'published';

                return (
                  <div key={sub.id} className="py-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-neutral-900 text-xs">
                          {sub.mod_title}
                        </span>
                        <span className="font-mono text-xs text-neutral-600">v{sub.version_str}</span>
                        <span
                          className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                            isPublished
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : isApproved
                              ? 'bg-sky-50 text-sky-800 border border-sky-200'
                              : isRejected
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {isPublished
                            ? '已发布 (不可变)'
                            : isApproved
                            ? '已批准待发布'
                            : isRejected
                            ? '已驳回 (需修订)'
                            : '待审队列中 (ready_for_review)'}
                        </span>
                      </div>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        提交于 {new Date(sub.submitted_at).toLocaleString()}
                      </span>
                    </div>

                    {/* Decision reason & reviewer info */}
                    {sub.decision_reason && (
                      <div
                        className={`p-3 rounded text-xs leading-relaxed ${
                          isRejected
                            ? 'bg-rose-50/70 border border-rose-200 text-rose-950'
                            : 'bg-neutral-50 border border-neutral-200 text-neutral-800'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold mb-1">
                          <span>
                            {isRejected ? '审核员驳回理由与修改意见:' : '审核员审批通过记录:'}
                          </span>
                          <span className="text-[11px] text-neutral-500 font-normal">
                            审核人: {sub.reviewer_name || 'Aegis 核心审核组'}
                          </span>
                        </div>
                        <p>{sub.decision_reason}</p>

                        {/* Rejection Revision Action (Section 1 requirement) */}
                        {isRejected && (
                          <div className="pt-2 mt-2 border-t border-rose-200/80 flex items-center justify-between">
                            <span className="text-[11px] text-rose-700">
                              根据契约规定，被驳回版本不可直接修改，请复制为新候选版本后重新提交。
                            </span>
                            <button
                              onClick={() => {
                                const newId = reviseRejectedVersion(sub.id);
                                if (newId) {
                                  setWorkbenchView('mods');
                                }
                              }}
                              className="px-3 py-1 text-xs font-medium text-white bg-rose-700 hover:bg-rose-800 rounded transition-colors flex items-center gap-1"
                            >
                              <RefreshCw className="w-3 h-3" />
                              基于此驳回修订为新草稿
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Scan report link */}
                    {subVer?.scan_report_id && (
                      <div className="flex items-center gap-2 pt-1 text-[11px]">
                        <button
                          onClick={() => setInspectingReportId(subVer.scan_report_id!)}
                          className="text-emerald-700 hover:underline flex items-center gap-1 font-medium"
                        >
                          <FileCheck className="w-3.5 h-3.5" />
                          查看关联的 Aegis 静态扫描报告
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* Mods & Candidate Versions Management View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: My Mods Selector */}
          <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-4 lg:col-span-1">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-2">
              <h2 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                我的模组列表 ({userMods.length})
              </h2>
              <button
                onClick={() => setIsNewModModalOpen(true)}
                className="text-xs text-emerald-700 hover:underline font-medium"
              >
                + 新建草稿
              </button>
            </div>

            <div className="space-y-1.5">
              {userMods.map((m) => {
                const isSelected = m.id === activeMod?.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelectedModId(m.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-all text-xs space-y-1 ${
                      isSelected
                        ? 'border-neutral-900 bg-neutral-50/80 font-medium'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-neutral-900 truncate max-w-[170px]">
                        {m.title}
                      </span>
                      <span className="text-[10px] font-mono text-neutral-400">
                        {m.category === 'spritepack' ? 'Spritepack' : 'Submod'}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-500 line-clamp-1">{m.summary}</p>
                    <div className="flex items-center justify-between pt-1 text-[10px] text-neutral-400">
                      <span>MAS {m.mas_version_range}</span>
                      <span>{m.is_published ? '已公开' : '草稿开发中'}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Selected Mod Management & Versions */}
          <div className="bg-white border border-neutral-200 rounded-lg p-6 space-y-6 lg:col-span-2">
            {activeMod ? (
              <>
                {/* Active Mod Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-neutral-100 pb-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-neutral-500 mb-1">
                      <span className="font-mono text-neutral-400">ID: {activeMod.id}</span>
                      <span>·</span>
                      <span className="font-medium text-emerald-700">{activeMod.category}</span>
                      <span>·</span>
                      <span>优先级权重: {activeMod.recommended_priority}</span>
                    </div>
                    <h2 className="text-base font-bold text-neutral-900">{activeMod.title}</h2>
                    <p className="text-xs text-neutral-600 mt-1">{activeMod.summary}</p>
                  </div>

                  <button
                    onClick={() => setIsNewVersionModalOpen(true)}
                    className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    + 创建候选版本
                  </button>
                </div>

                {/* Versions List for this Mod */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                      候选与发布版本列表 ({activeModVersions.length})
                    </h3>
                    <span className="text-[11px] text-neutral-400">
                      上传 ZIP 归档后将自动触发静态解析流水线
                    </span>
                  </div>

                  {activeModVersions.length === 0 ? (
                    <div className="py-8 text-center border border-dashed border-neutral-200 rounded-lg space-y-2">
                      <p className="text-xs text-neutral-500">当前模组尚无任何候选版本。</p>
                      <button
                        onClick={() => setIsNewVersionModalOpen(true)}
                        className="text-xs text-emerald-700 hover:underline font-medium"
                      >
                        立即创建第一个版本 (如 1.0.0)
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {activeModVersions.map((v) => {
                        const report = v.scan_report_id ? scanReports[v.scan_report_id] : null;
                        const hasBlockers = report && report.blockers.length > 0;
                        const isUnderReview = v.state === 'ready_for_review';
                        const isPublished = v.state === 'published';
                        const isDraft = v.state === 'draft';
                        const isUploaded = v.state === 'uploaded';

                        return (
                          <div
                            key={v.id}
                            className="p-4 rounded-lg border border-neutral-200 bg-neutral-50/50 space-y-3"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-sm text-neutral-900 font-mono">
                                  v{v.version}
                                </span>
                                <span
                                  className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                                    isPublished
                                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                      : isUnderReview
                                      ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                      : v.state === 'rejected'
                                      ? 'bg-rose-50 text-rose-800 border border-rose-200'
                                      : 'bg-neutral-100 text-neutral-700'
                                  }`}
                                >
                                  状态: {v.state}
                                </span>
                                {v.is_immutable && (
                                  <span className="text-[10px] text-neutral-400 font-mono">
                                    [不可变归档]
                                  </span>
                                )}
                              </div>

                              <span className="text-[11px] text-neutral-400 font-mono">
                                创建于: {new Date(v.created_at).toLocaleDateString()}
                              </span>
                            </div>

                            {/* Release Notes */}
                            <p className="text-xs text-neutral-600 bg-white p-2.5 rounded border border-neutral-200/80">
                              {v.release_notes || '暂无发布说明'}
                            </p>

                            {/* Scan Summary Banner if report available */}
                            {report && (
                              <div className="p-3 bg-white rounded border border-neutral-200 space-y-2 text-xs">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-1.5 font-medium text-neutral-800">
                                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                                    <span>Aegis 扫描完成: {report.files.length} 个文件</span>
                                    {report.resource_stats.binary_flag && (
                                      <span className="text-[10px] font-mono text-rose-600 font-semibold">
                                        (检出二进制)
                                      </span>
                                    )}
                                  </div>
                                  <button
                                    onClick={() => setInspectingReportId(report.id)}
                                    className="text-xs text-emerald-700 hover:underline font-medium"
                                  >
                                    查阅完整报告与文件树 →
                                  </button>
                                </div>

                                {report.blockers.length > 0 && (
                                  <div className="p-2 bg-rose-50 rounded border border-rose-200 text-rose-800 text-[11px] space-y-1">
                                    <div className="font-semibold flex items-center gap-1">
                                      <AlertCircle className="w-3.5 h-3.5" />
                                      存在 {report.blockers.length} 项阻断错误 (禁止提交审核):
                                    </div>
                                    <ul className="list-disc list-inside space-y-0.5">
                                      {report.blockers.map((b, idx) => (
                                        <li key={idx}>{b}</li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Version Action Toolbar */}
                            <div className="pt-1 flex flex-wrap items-center justify-between gap-3 text-xs">
                              <div className="flex items-center gap-2">
                                {/* Upload / Re-upload ZIP Trigger */}
                                {!isPublished && (
                                  <div className="flex items-center gap-1.5">
                                    <button
                                      disabled={isUploading}
                                      onClick={() => handleUploadArchiveSim(v.id, 'normal')}
                                      className="px-3 py-1.5 font-medium text-neutral-800 bg-white hover:bg-neutral-100 rounded border border-neutral-300 flex items-center gap-1.5 transition-colors"
                                    >
                                      <Upload className="w-3.5 h-3.5 text-neutral-600" />
                                      {report ? '重新上传 ZIP 归档' : '上传 ZIP 归档 (application/zip)'}
                                    </button>

                                    {/* Test Presets for evaluation */}
                                    <button
                                      title="模拟包含 DLL 二进制违规的测试包"
                                      onClick={() => handleUploadArchiveSim(v.id, 'unsafe')}
                                      className="px-2 py-1.5 text-[11px] text-rose-700 hover:bg-rose-50 rounded border border-rose-200"
                                    >
                                      + 模拟安全阻断 ZIP
                                    </button>
                                  </div>
                                )}
                              </div>

                              {/* Submit for Review Action (Section 1 & 2 contract) */}
                              {!isPublished && !isUnderReview && (
                                <button
                                  disabled={!report || Boolean(hasBlockers)}
                                  onClick={() => submitVersionForReview(v.id)}
                                  className={`px-3.5 py-1.5 font-medium rounded flex items-center gap-1.5 transition-colors shadow-xs ${
                                    !report || hasBlockers
                                      ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                                      : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                                  }`}
                                >
                                  <Send className="w-3.5 h-3.5" />
                                  提交审核 (POST /submit)
                                </button>
                              )}

                              {isUnderReview && (
                                <span className="text-xs text-amber-700 flex items-center gap-1">
                                  <Clock className="w-3.5 h-3.5" />
                                  审核中，等待审核员决策
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="py-12 text-center text-neutral-400 text-xs">
                请先在左侧选择或新建一个模组草稿。
              </div>
            )}
          </div>
        </div>
      )}

      {/* Uploading Progress Modal */}
      {isUploading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full space-y-4 text-center shadow-xl animate-in fade-in">
            <Upload className="w-8 h-8 text-emerald-700 mx-auto animate-bounce" />
            <div>
              <h3 className="text-sm font-semibold text-neutral-900">
                正在上传 ZIP 归档并执行静态安全扫描
              </h3>
              <p className="text-xs text-neutral-500 mt-1">
                解构目录树、计算 SHA-256、检查 Ren'Py 脚本语法与 Sprite 锚点...
              </p>
            </div>
            <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
              <div
                className="bg-emerald-600 h-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            <div className="text-[11px] font-mono text-neutral-400">
              Idempotency-Key 校验通过 · {uploadProgress}%
            </div>
          </div>
        </div>
      )}

      {/* Full Scan Report Inspector Modal */}
      {inspectingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-50/50">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <div>
                  <h3 className="text-sm font-bold text-neutral-900">
                    Aegis 逐文件静态扫描与合规报告 (Scan Report)
                  </h3>
                  <div className="text-[11px] text-neutral-500 font-mono">
                    ID: {inspectingReport.id} · 扫描状态: {inspectingReport.status}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setInspectingReportId(null)}
                className="text-neutral-400 hover:text-neutral-700 text-xs px-2 py-1 rounded"
              >
                关闭
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 text-xs text-neutral-700 leading-relaxed">
              {/* Blockers & Warnings */}
              {inspectingReport.blockers.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-900 space-y-1.5">
                  <div className="font-semibold flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-rose-700" />
                    静态检测阻断原因 (Blockers - 禁止提交上线):
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    {inspectingReport.blockers.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              )}

              {inspectingReport.warnings.length > 0 && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 space-y-1">
                  <div className="font-semibold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-700" />
                    合规性警告提示 (Warnings - 审核员将重点关注):
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-xs">
                    {inspectingReport.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Submod Registration Confidence Rule (Section 2 explicit requirement) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-xs">
                    静态 Submod 注册标识 (Registrations)
                  </h4>
                  <span className="text-[11px] text-rose-700 font-medium">
                    * 契约规范：未知静态解析结果不得显示成“安全”
                  </span>
                </div>
                <div className="border border-neutral-200 rounded divide-y divide-neutral-100">
                  {inspectingReport.registrations.map((reg) => (
                    <div
                      key={reg.submod_id}
                      className="p-3 flex items-center justify-between bg-white text-xs"
                    >
                      <div>
                        <div className="font-semibold text-neutral-900">{reg.name}</div>
                        <div className="text-[11px] text-neutral-500 font-mono">
                          ID: {reg.submod_id} · 版本: {reg.version} · 作者: {reg.author}
                        </div>
                      </div>
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded font-semibold ${
                          reg.confidence === 'known'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-rose-100 text-rose-900 border border-rose-300'
                        }`}
                      >
                        解析置信度: {reg.confidence.toUpperCase()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sprite Identities & Derived Gifts */}
              {inspectingReport.sprite_identities.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-xs">
                    Spritepack 衍生礼物登记 (.gift 解析)
                  </h4>
                  <div className="border border-neutral-200 rounded divide-y divide-neutral-100">
                    {inspectingReport.sprite_identities.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 flex items-center justify-between bg-white text-xs"
                      >
                        <div>
                          <div className="font-semibold text-neutral-900 font-mono">
                            {item.giftname}.gift
                          </div>
                          <div className="text-[11px] text-neutral-500">
                            类别: {item.category} · 包含姿态: {item.poses.join(', ')}
                          </div>
                        </div>
                        <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          礼物名已锚定
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Package Files Tree / Detailed Table */}
              <div className="space-y-2">
                <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-xs">
                  逐文件清单与校验和 (Files Tree)
                </h4>
                <div className="border border-neutral-200 rounded overflow-hidden">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-medium">
                      <tr>
                        <th className="py-2 px-3">路径与文件类别</th>
                        <th className="py-2 px-3">大小</th>
                        <th className="py-2 px-3">SHA-256 校验和</th>
                        <th className="py-2 px-3">警告</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {inspectingReport.files.map((f, i) => (
                        <tr key={i} className="hover:bg-neutral-50/70">
                          <td className="py-2 px-3">
                            <div className="font-mono text-neutral-900 font-medium text-[11px]">
                              {f.source_path}
                            </div>
                            <div className="text-[10px] text-neutral-400 capitalize">
                              种类: {f.kind}
                            </div>
                          </td>
                          <td className="py-2 px-3 font-mono tabular-nums text-neutral-600 text-[11px]">
                            {(f.size_bytes / 1024).toFixed(1)} KB
                          </td>
                          <td className="py-2 px-3 font-mono tabular-nums text-[10px] text-neutral-500 max-w-[150px] truncate">
                            {f.sha256}
                          </td>
                          <td className="py-2 px-3 text-[11px]">
                            {f.warnings && f.warnings.length > 0 ? (
                              <span className="text-rose-600 font-medium">
                                {f.warnings.join('; ')}
                              </span>
                            ) : (
                              <span className="text-emerald-700 font-mono">通过</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="px-6 py-3 border-t border-neutral-200 bg-neutral-50/50 flex justify-end">
              <button
                onClick={() => setInspectingReportId(null)}
                className="px-4 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors"
              >
                完成查看
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Mod Draft Modal */}
      {isNewModModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900">新建模组草稿 (POST /author/mods)</h3>
              <button
                onClick={() => setIsNewModModalOpen(false)}
                className="text-neutral-400 hover:text-neutral-600 text-xs"
              >
                取消
              </button>
            </div>

            <form onSubmit={handleCreateDraftSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-neutral-700 mb-1">模组标题 (Title)</label>
                <input
                  type="text"
                  required
                  placeholder="例如: Monika Cozy Winter Dates"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  一句话简介 (Summary)
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="简要概括该模组为玩家带来的全新体验与内容..."
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-neutral-700 mb-1">分类 (Category)</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as ModCategory)}
                    className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600 bg-white"
                  >
                    <option value="submod">Submod (功能扩展/剧本模组)</option>
                    <option value="spritepack">Spritepack (服饰/发带/配件)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-neutral-700 mb-1">
                    MAS 兼容范围
                  </label>
                  <input
                    type="text"
                    required
                    value={newMasRange}
                    onChange={(e) => setNewMasRange(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-neutral-700 mb-1">
                    推荐优先级 (0-100)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={newPriority}
                    onChange={(e) => setNewPriority(Number(e.target.value))}
                    className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-medium text-neutral-700 mb-1">标签 (逗号分隔)</label>
                  <input
                    type="text"
                    value={newTagsStr}
                    onChange={(e) => setNewTagsStr(e.target.value)}
                    placeholder="dialogue, cozy, dates"
                    className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsNewModModalOpen(false)}
                  className="px-3 py-1.5 text-neutral-600 hover:text-neutral-900"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-emerald-700 hover:bg-emerald-800 rounded font-medium transition-colors"
                >
                  保存草稿
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Candidate Version Modal */}
      {isNewVersionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900">
                创建候选版本 (POST /author/mods/{activeMod?.id}/versions)
              </h3>
              <button
                onClick={() => setIsNewVersionModalOpen(false)}
                className="text-neutral-400 hover:text-neutral-600 text-xs"
              >
                取消
              </button>
            </div>

            <form onSubmit={handleCreateVersionSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  版本标识 (Version String)
                </label>
                <input
                  type="text"
                  required
                  placeholder="例如: 1.3.0 或 1.3.0-rc1"
                  value={newVerString}
                  onChange={(e) => setNewVerString(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600 font-mono"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  发行说明 (Release Notes)
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="说明此版本的新增内容、修复漏洞与破坏性变更..."
                  value={newReleaseNotes}
                  onChange={(e) => setNewReleaseNotes(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsNewVersionModalOpen(false)}
                  className="px-3 py-1.5 text-neutral-600 hover:text-neutral-900"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-neutral-900 hover:bg-neutral-800 rounded font-medium transition-colors"
                >
                  确认建立候选版本
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GitHub Releases Import Modal */}
      {isGithubImportOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Github className="w-4 h-4 text-neutral-900" />
                <h3 className="text-sm font-semibold text-neutral-900">
                  GitHub Releases 自动化草稿导入
                </h3>
              </div>
              <button
                onClick={() => setIsGithubImportOpen(false)}
                className="text-neutral-400 hover:text-neutral-600 text-xs"
              >
                取消
              </button>
            </div>

            <form onSubmit={handleGithubImport} className="p-5 space-y-4 text-xs">
              <p className="text-neutral-600 leading-relaxed">
                按照契约要求（Section 3），系统支持将 GitHub Release URL
                或资产直接导入为草稿，并走完全相同的 Aegis 静态安全扫描与规范审核流程。
              </p>

              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  GitHub Release 资产地址 (URL)
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://github.com/monika-fan/my-submod/releases/tag/v1.0.0"
                  value={githubReleaseUrl}
                  onChange={(e) => setGithubReleaseUrl(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-emerald-600 font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsGithubImportOpen(false)}
                  className="px-3 py-1.5 text-neutral-600 hover:text-neutral-900"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-neutral-900 hover:bg-neutral-800 rounded font-medium transition-colors"
                >
                  开始解析导入
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
