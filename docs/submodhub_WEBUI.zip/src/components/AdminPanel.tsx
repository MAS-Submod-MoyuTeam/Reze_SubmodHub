import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types/submodhub';
import {
  ShieldAlert,
  Users,
  EyeOff,
  Server,
  Activity,
  CheckCircle2,
  AlertTriangle,
  History,
  Lock,
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const {
    currentUser,
    hasRole,
    versions,
    mods,
    auditLogs,
    updateUserRoles,
    unpublishVersion,
    showToast,
  } = useApp();

  const isAdmin = hasRole('admin');

  // Role Assignment Modal
  const [roleModalUser, setRoleModalUser] = useState<{ id: string; name: string; roles: UserRole[] } | null>(null);
  const [selectedRoles, setSelectedRoles] = useState<UserRole[]>([]);
  const [roleChangeReason, setRoleChangeReason] = useState('');

  // Unpublish Modal
  const [unpublishModalVerId, setUnpublishModalVerId] = useState<string | null>(null);
  const [unpublishReason, setUnpublishReason] = useState('');

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <Lock className="w-10 h-10 text-neutral-400 mx-auto" />
        <h2 className="text-base font-bold text-neutral-800">需要系统管理员 (Admin) 权限</h2>
        <p className="text-xs text-neutral-500 max-w-md mx-auto">
          管理与审计后台仅向系统管理员开放。你可以通过顶部导航栏右上角的身份切换器，快速切换为总管理角色 (Admin)。
        </p>
      </div>
    );
  }

  // Demo users list for administration
  const demoUsers: { id: string; name: string; username: string; roles: UserRole[]; email: string }[] = [
    {
      id: 'user_monika_fan',
      name: '莫妮卡守望者',
      username: 'MonikaDreamer',
      roles: ['author'],
      email: 'monika_dreamer@submodhub.org',
    },
    {
      id: 'user_aegis_reviewer',
      name: 'Aegis 核心审核员',
      username: 'AegisReviewer',
      roles: ['author', 'reviewer'],
      email: 'security_inspector@aegis.org',
    },
    {
      id: 'user_admin',
      name: '社区总管理',
      username: 'RootArchon',
      roles: ['author', 'reviewer', 'admin'],
      email: 'admin_ops@submodhub.org',
    },
    {
      id: 'user_new_visitor',
      name: '普通游客用户',
      username: 'JustMonika2026',
      roles: ['visitor'],
      email: 'visitor_fan@ddlc.net',
    },
  ];

  const publishedVersions = versions.filter((v) => v.state === 'published' || v.state === 'unpublished');

  const handleOpenRoleModal = (u: typeof demoUsers[0]) => {
    setRoleModalUser(u);
    setSelectedRoles(u.roles);
    setRoleChangeReason('管理员合规权限调配 (POST /admin/users/{id}/roles)');
  };

  const handleConfirmRoleChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleModalUser) return;
    updateUserRoles(roleModalUser.id, selectedRoles, roleChangeReason);
    setRoleModalUser(null);
  };

  const handleConfirmUnpublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unpublishModalVerId) return;
    unpublishVersion(unpublishModalVerId, unpublishReason);
    setUnpublishModalVerId(null);
    setUnpublishReason('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="bg-white border border-neutral-200 rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <span className="font-semibold text-neutral-900">{currentUser?.display_name}</span>
            <span>·</span>
            <span>SubmodHub 系统中控台</span>
          </div>
          <h1 className="text-lg font-bold text-neutral-900 tracking-tight mt-0.5">
            用户 RBAC 角色权限、版本合规下架与集群服务状态
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            下架操作为软下架（保持不可变归档字节，仅公开隐藏并记录审计）；所有提权与变更操作强制记录审计日志
          </p>
        </div>
      </div>

      {/* Microservices & Configuration Status Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
        {[
          { name: 'Aegis 静态扫描引擎', status: '正常运行 (Healthy)', latency: '32ms', load: '12% 工作负载' },
          { name: 'S3 兼容归档存储桶', status: '正常 (SHA-256 校验)', latency: '18ms', load: '不可变锁定' },
          { name: 'Flarum 认证代理网桥', status: '已连接 (Proxy Online)', latency: '45ms', load: '代验有效' },
          { name: 'GitHub OAuth PKCE 服务', status: '正常运行', latency: '60ms', load: '回调通道就绪' },
          { name: 'Redis 目录游标缓存', status: '低延迟可用', latency: '4ms', load: '离线快照已同步' },
        ].map((svc, i) => (
          <div key={i} className="bg-white p-3.5 rounded-lg border border-neutral-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-900 truncate">{svc.name}</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            </div>
            <div className="text-[11px] text-emerald-700 font-medium">{svc.status}</div>
            <div className="text-[10px] text-neutral-400 font-mono flex items-center justify-between pt-1 border-t border-neutral-100">
              <span>时延: {svc.latency}</span>
              <span>{svc.load}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid: User RBAC Management & Version Takedown Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User RBAC Management */}
        <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-neutral-700" />
              <h2 className="text-sm font-bold text-neutral-900">
                用户 RBAC 角色赋权管理 (POST /admin/users/{'{id}'}/roles)
              </h2>
            </div>
            <span className="text-[11px] text-neutral-400 font-mono">显式角色集</span>
          </div>

          <div className="divide-y divide-neutral-100">
            {demoUsers.map((u) => (
              <div key={u.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-neutral-900">{u.name}</div>
                  <div className="text-[11px] text-neutral-500 font-mono">
                    {u.username} · {u.email}
                  </div>
                  <div className="flex flex-wrap items-center gap-1 pt-1">
                    {u.roles.map((r) => (
                      <span
                        key={r}
                        className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-100 text-neutral-700 border border-neutral-200"
                      >
                        {r}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => handleOpenRoleModal(u)}
                  className="px-2.5 py-1 text-xs text-neutral-700 hover:bg-neutral-100 rounded border border-neutral-200 transition-colors"
                >
                  配置角色
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Version Unpublish / Takedown Manager */}
        <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-neutral-700" />
              <h2 className="text-sm font-bold text-neutral-900">
                模组版本下架管理 (POST /admin/versions/{'{id}'}/unpublish)
              </h2>
            </div>
            <span className="text-[11px] text-neutral-400">保留不可变归档字节</span>
          </div>

          <div className="divide-y divide-neutral-100">
            {publishedVersions.map((v) => {
              const mod = mods.find((m) => m.id === v.mod_id);
              const isUnpublished = v.state === 'unpublished';

              return (
                <div key={v.id} className="py-3 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-neutral-900">{mod?.title || v.mod_id}</span>
                      <span className="font-mono text-neutral-600">v{v.version}</span>
                      {isUnpublished && (
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-rose-50 text-rose-800 border border-rose-200 font-semibold">
                          已下架 (隐藏)
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-neutral-400 font-mono truncate max-w-[280px]">
                      SHA-256: {v.sha256}
                    </div>
                    {v.unpublish_reason && (
                      <div className="text-[11px] text-rose-700 bg-rose-50/60 p-1.5 rounded border border-rose-100">
                        下架原因: {v.unpublish_reason}
                      </div>
                    )}
                  </div>

                  {!isUnpublished ? (
                    <button
                      onClick={() => {
                        setUnpublishModalVerId(v.id);
                        setUnpublishReason('应合规安全或版权投诉要求暂时下架，留存不可变备份。');
                      }}
                      className="px-2.5 py-1 text-xs text-rose-700 hover:bg-rose-50 rounded border border-rose-200 transition-colors"
                    >
                      安全下架
                    </button>
                  ) : (
                    <span className="text-[11px] text-neutral-400 font-mono">已限制访问</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Role Assignment Modal */}
      {roleModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-900">
                变更用户角色: {roleModalUser.name}
              </h3>
              <button
                onClick={() => setRoleModalUser(null)}
                className="text-neutral-400 hover:text-neutral-600 text-xs"
              >
                取消
              </button>
            </div>

            <form onSubmit={handleConfirmRoleChange} className="p-5 space-y-4 text-xs">
              <div className="space-y-2">
                <label className="block font-medium text-neutral-700">勾选赋予的角色集</label>
                <div className="space-y-1.5">
                  {(['visitor', 'author', 'reviewer', 'admin'] as UserRole[]).map((r) => {
                    const isChecked = selectedRoles.includes(r);
                    return (
                      <label
                        key={r}
                        className="flex items-center gap-2 p-2 rounded border border-neutral-200 hover:bg-neutral-50 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedRoles((prev) => [...prev, r]);
                            } else {
                              setSelectedRoles((prev) => prev.filter((item) => item !== r));
                            }
                          }}
                        />
                        <span className="font-medium text-neutral-800 capitalize">{r}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  变更原因 (Mandatory Audit Reason)
                </label>
                <input
                  type="text"
                  required
                  value={roleChangeReason}
                  onChange={(e) => setRoleChangeReason(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setRoleModalUser(null)}
                  className="px-3 py-1.5 text-neutral-600 hover:text-neutral-900"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-neutral-900 hover:bg-neutral-800 rounded font-medium transition-colors"
                >
                  保存并记录审计
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Unpublish Reason Modal */}
      {unpublishModalVerId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-neutral-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-rose-900">
                确认执行软下架 (Takedown Version)
              </h3>
              <button
                onClick={() => setUnpublishModalVerId(null)}
                className="text-neutral-400 hover:text-neutral-600 text-xs"
              >
                取消
              </button>
            </div>

            <form onSubmit={handleConfirmUnpublish} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 rounded border border-amber-200 text-amber-900 leading-relaxed">
                按照规范，公开版本发布后不可变；下架意味着从公开目录隐藏该版本，但保留历史归档字节用于客户端哈希核验与旧计划回滚。
              </div>

              <div>
                <label className="block font-medium text-neutral-700 mb-1">
                  下架原因 (Audit Reason)
                </label>
                <textarea
                  rows={3}
                  required
                  value={unpublishReason}
                  onChange={(e) => setUnpublishReason(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 rounded border border-neutral-300 focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setUnpublishModalVerId(null)}
                  className="px-3 py-1.5 text-neutral-600 hover:text-neutral-900"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-white bg-rose-700 hover:bg-rose-800 rounded font-medium transition-colors"
                >
                  确认下架
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
