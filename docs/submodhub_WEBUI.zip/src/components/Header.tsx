import React, { useState } from 'react';
import { useApp, NavTab } from '../context/AppContext';
import { UserRole } from '../types/submodhub';
import { Wifi, WifiOff, User as UserIcon, Shield, ChevronDown, Check } from 'lucide-react';

interface HeaderProps {
  onOpenLoginModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenLoginModal }) => {
  const {
    activeTab,
    setActiveTab,
    currentUser,
    switchRolePersona,
    logout,
    isOffline,
    setIsOffline,
  } = useApp();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const navLinks: { id: NavTab; label: string; minRole?: UserRole }[] = [
    { id: 'catalog', label: '模组目录' },
    { id: 'author', label: '作者工作台' },
    { id: 'reviewer', label: '审核工作台' },
    { id: 'admin', label: '管理与审计' },
    { id: 'client', label: '客户端预览' },
    { id: 'states', label: '契约状态机' },
  ];

  const currentPersonaLabel = !currentUser
    ? '访客 (未登录)'
    : currentUser.roles.includes('admin')
    ? '管理员 (Admin)'
    : currentUser.roles.includes('reviewer')
    ? '审核员 (Reviewer)'
    : '作者 (Author)';

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => setActiveTab('catalog')}
          className="text-lg font-semibold tracking-tight text-neutral-950 hover:text-emerald-700 transition-colors shrink-0"
        >
          SubmodHub
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`relative py-1 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-neutral-900 font-semibold'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          {/* Offline Cache Simulator Toggle */}
          <button
            onClick={() => setIsOffline(!isOffline)}
            title={isOffline ? '当前为模拟离线缓存模式，点击切回在线' : '点击模拟客户端网络中断与离线缓存'}
            className={`p-1.5 rounded text-xs transition-colors flex items-center gap-1.5 ${
              isOffline
                ? 'bg-amber-100 text-amber-800'
                : 'text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100'
            }`}
          >
            {isOffline ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
            <span className="hidden lg:inline text-xs font-mono">{isOffline ? '离线缓存' : '在线'}</span>
          </button>

          {/* Persona / Role Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200/80 rounded transition-colors whitespace-nowrap"
            >
              <Shield className="w-3.5 h-3.5 text-neutral-500" />
              <span className="truncate max-w-[120px]">{currentPersonaLabel}</span>
              <ChevronDown className="w-3 h-3 text-neutral-400" />
            </button>

            {roleMenuOpen && (
              <div
                className="absolute right-0 mt-1.5 w-56 bg-white border border-neutral-200 rounded-md shadow-lg py-1 z-50 text-xs"
                onMouseLeave={() => setRoleMenuOpen(false)}
              >
                <div className="px-3 py-1.5 text-[11px] font-medium text-neutral-400 uppercase tracking-wider border-b border-neutral-100">
                  快速切换演示角色
                </div>
                <button
                  onClick={() => {
                    switchRolePersona('visitor');
                    setRoleMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 flex items-center justify-between hover:bg-neutral-50"
                >
                  <div>
                    <div className="font-medium text-neutral-800">访客 (Guest)</div>
                    <div className="text-[11px] text-neutral-500">公开目录浏览、下载描述符</div>
                  </div>
                  {!currentUser && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                </button>
                <button
                  onClick={() => {
                    switchRolePersona('author');
                    setRoleMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 flex items-center justify-between hover:bg-neutral-50"
                >
                  <div>
                    <div className="font-medium text-neutral-800">作者 (Author)</div>
                    <div className="text-[11px] text-neutral-500">新建草稿、ZIP上传、扫描报告、提交</div>
                  </div>
                  {currentUser && !currentUser.roles.includes('reviewer') && (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  )}
                </button>
                <button
                  onClick={() => {
                    switchRolePersona('reviewer');
                    setRoleMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 flex items-center justify-between hover:bg-neutral-50"
                >
                  <div>
                    <div className="font-medium text-neutral-800">审核员 (Reviewer)</div>
                    <div className="text-[11px] text-neutral-500">待审队列、文件树、批准/驳回/发布</div>
                  </div>
                  {currentUser?.roles.includes('reviewer') && !currentUser?.roles.includes('admin') && (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  )}
                </button>
                <button
                  onClick={() => {
                    switchRolePersona('admin');
                    setRoleMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 flex items-center justify-between hover:bg-neutral-50"
                >
                  <div>
                    <div className="font-medium text-neutral-800">总管理 (Admin)</div>
                    <div className="text-[11px] text-neutral-500">角色分配、模组下架、系统审计</div>
                  </div>
                  {currentUser?.roles.includes('admin') && (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Account Button */}
          {currentUser ? (
            <button
              onClick={onOpenLoginModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-800 bg-neutral-50 border border-neutral-200 hover:bg-neutral-100 rounded transition-colors whitespace-nowrap"
            >
              <UserIcon className="w-3.5 h-3.5 text-neutral-500" />
              <span className="truncate max-w-[90px]">{currentUser.username}</span>
            </button>
          ) : (
            <button
              onClick={onOpenLoginModal}
              className="px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors whitespace-nowrap"
            >
              登录
            </button>
          )}
        </div>
      </div>

      {/* Mobile nav bar fallback */}
      <div className="md:hidden flex items-center gap-1 overflow-x-auto px-4 py-1.5 border-t border-neutral-100 text-xs">
        {navLinks.map((link) => (
          <button
            key={link.id}
            onClick={() => setActiveTab(link.id)}
            className={`px-2.5 py-1 rounded whitespace-nowrap ${
              activeTab === link.id
                ? 'bg-neutral-900 text-white font-medium'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            {link.label}
          </button>
        ))}
      </div>
    </header>
  );
};
