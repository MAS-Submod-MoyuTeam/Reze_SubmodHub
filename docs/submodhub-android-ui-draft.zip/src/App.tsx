import React, { useState, useEffect, useTransition } from 'react';
import {
  INITIAL_INSTALLATIONS,
  INITIAL_MODS,
  INITIAL_INSTALLED_MODS,
  INITIAL_OPERATIONS,
  generateSamplePlan,
} from './mock/data';
import {
  Installation,
  Mod,
  InstalledMod,
  Operation,
  Plan,
} from './types/submodhub';
import { AndroidFrame } from './components/AndroidFrame';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar, NavTabId } from './components/BottomNavBar';
import { CatalogTab } from './components/CatalogTab';
import { InstalledTab } from './components/InstalledTab';
import { OperationsTab } from './components/OperationsTab';
import { StorageTab } from './components/StorageTab';
import { ModDetailModal } from './components/ModDetailModal';
import { InstallPlanSheet } from './components/InstallPlanSheet';
import { ExternalChangeModal } from './components/ExternalChangeModal';
import { AdoptModal } from './components/AdoptModal';
import { PriorityModal } from './components/PriorityModal';
import { ContractInspector } from './components/ContractInspector';
import { InstancePickerModal } from './components/InstancePickerModal';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabId>('catalog');
  const [installations, setInstallations] = useState<Installation[]>(INITIAL_INSTALLATIONS);
  const [currentInstallationId, setCurrentInstallationId] = useState<string>('inst_android_primary');
  const [mods, setMods] = useState<Mod[]>(INITIAL_MODS);
  const [installedMods, setInstalledMods] = useState<InstalledMod[]>(INITIAL_INSTALLED_MODS);
  const [operations, setOperations] = useState<Operation[]>(INITIAL_OPERATIONS);

  // Modals & Sheets State
  const [selectedModForDetail, setSelectedModForDetail] = useState<Mod | null>(null);
  const [activePlan, setActivePlan] = useState<Plan | null>(null);
  const [driftOperation, setDriftOperation] = useState<Operation | null>(null);
  const [unmanagedToAdopt, setUnmanagedToAdopt] = useState<InstalledMod | null>(null);
  const [modForPriority, setModForPriority] = useState<InstalledMod | null>(null);
  const [isInspectorOpen, setIsInspectorOpen] = useState(false);
  const [isInstancePickerOpen, setIsInstancePickerOpen] = useState(false);

  // Simulator / Scenario State
  const [currentScenario, setCurrentScenario] = useState<string>('normal');
  const [offlineMode, setOfflineMode] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [toast, setToast] = useState<{ message: string; type?: 'info' | 'success' | 'warn' } | null>(null);

  const currentInstallation =
    installations.find((i) => i.id === currentInstallationId) || installations[0];

  const showToast = (message: string, type: 'info' | 'success' | 'warn' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3200);
  };

  // Plan generation from Mod Detail
  const handleRequestPlan = (mod: Mod, targetVersionId: string) => {
    const plan = generateSamplePlan(mod, targetVersionId, currentInstallation);
    setActivePlan(plan);
  };

  // Plan confirmation execution (ApplyPlan RPC / Go binding)
  const handleConfirmApplyPlan = (plan: Plan) => {
    const targetMod = mods.find((m) => m.id === plan.mod_id);
    const modTitle = targetMod ? targetMod.title : plan.mod_id;
    const version = targetMod?.versions.find((v) => v.id === plan.version_id)?.version || '1.0.0';

    const newOp: Operation = {
      operation_id: `op_${Date.now()}`,
      installation_id: plan.installation_id,
      plan_id: plan.plan_id,
      mod_title: modTitle,
      mod_id: plan.mod_id,
      version: version,
      kind: plan.kind === 'priority_change' ? 'priority' : plan.kind,
      stage: 'downloading',
      status: 'in_progress',
      progress_percent: 20,
      current_file: plan.changes[0]?.target_path,
      started_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      log_lines: [
        `[${new Date().toLocaleTimeString()}] ApplyPlan 启动: 准备执行 ${plan.changes.length} 个文件变更`,
        `[${new Date().toLocaleTimeString()}] 校验 SAF 根权限与游戏运行状态 [OK]`,
        `[${new Date().toLocaleTimeString()}] 开始下载并比对 SHA-256...`,
      ],
    };

    setOperations((prev) => [newOp, ...prev]);
    setActivePlan(null);
    setSelectedModForDetail(null);
    setActiveTab('operations');
    showToast(`安装计划已生效，正在执行写入事务: ${modTitle}`, 'success');

    // Simulate multi-stage progression according to contract
    setTimeout(() => {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === newOp.operation_id
            ? {
                ...op,
                stage: 'scanning',
                progress_percent: 45,
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 下载完成，执行本地 AST 语法树安全扫描 [OK]`,
                ],
              }
            : op
        )
      );
    }, 1200);

    setTimeout(() => {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === newOp.operation_id
            ? {
                ...op,
                stage: 'backed_up',
                progress_percent: 70,
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 创建原子回滚快照点 (.submodhub_backups/) [OK]`,
                  `[${new Date().toLocaleTimeString()}] 写入新模组文件: ${plan.changes[0]?.target_path}`,
                ],
              }
            : op
        )
      );
    }, 2400);

    setTimeout(() => {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === newOp.operation_id
            ? {
                ...op,
                stage: 'committed',
                status: 'completed',
                progress_percent: 100,
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 全部文件写入完成，更新本地 SQLite 索引基线 [OK]`,
                  `[${new Date().toLocaleTimeString()}] 事务提交完成 (COMMITTED)`,
                ],
              }
            : op
        )
      );

      // Register or update installed mods list
      setInstalledMods((prev) => {
        const existing = prev.find((m) => m.mod_id === plan.mod_id);
        if (existing) {
          return prev.map((m) =>
            m.mod_id === plan.mod_id
              ? {
                  ...m,
                  current_version: version,
                  has_update: false,
                  priority: plan.target_priority ?? m.priority,
                  installed_at: new Date().toISOString(),
                }
              : m
          );
        } else {
          return [
            {
              mod_id: plan.mod_id,
              title: modTitle,
              author_name: targetMod?.author.display_name || 'Community',
              category: targetMod?.category || 'submod',
              current_version: version,
              latest_available_version: version,
              has_update: false,
              priority: plan.target_priority ?? 10,
              managed: true,
              installed_at: new Date().toISOString(),
              file_count: plan.changes.length,
            },
            ...prev,
          ];
        }
      });

      showToast(`模组「${modTitle}」已成功安装并提交！`, 'success');
    }, 3800);
  };

  // Reauthorize Android SAF
  const handleReauthorizeSaf = (id: string) => {
    setInstallations((prev) =>
      prev.map((inst) =>
        inst.id === id ? { ...inst, permission_state: 'granted', last_verified_at: new Date().toISOString() } : inst
      )
    );
    showToast('Android SAF 文档树持久访问权限已重新获取！', 'success');
  };

  // Discover MAS Installations
  const handleDiscoverInstallations = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      showToast('已扫描设备存储，确认找到 2 个 MAS 游戏目录。', 'info');
    }, 800);
  };

  // Toggle MAS process running state
  const handleToggleGameRunning = () => {
    setInstallations((prev) =>
      prev.map((inst) =>
        inst.id === currentInstallationId
          ? { ...inst, is_running: !inst.is_running }
          : inst
      )
    );
    const willRun = !currentInstallation.is_running;
    showToast(
      willRun
        ? '已模拟 MAS 游戏在前台运行，安装与写入已触发协议阻断！'
        : 'MAS 游戏已退出，文件锁已释放，恢复正常写入。',
      willRun ? 'warn' : 'success'
    );
  };

  // Explicit Adoption of unmanaged mod
  const handleConfirmAdopt = (modId: string, title: string, priority: number) => {
    setInstalledMods((prev) =>
      prev.map((m) =>
        m.mod_id === modId
          ? {
              ...m,
              title: title,
              author_name: '本地自制 / 已收养',
              managed: true,
              priority: priority,
              current_version: '1.0.0 (收养基线)',
            }
          : m
      )
    );
    setUnmanagedToAdopt(null);
    showToast(`未托管文件已显式收养为受管模组「${title}」！`, 'success');
  };

  // Apply Priority Change
  const handleApplyPriority = (modId: string, newPriority: number) => {
    setInstalledMods((prev) =>
      prev.map((m) => (m.mod_id === modId ? { ...m, priority: newPriority } : m))
    );
    setModForPriority(null);
    showToast(`优先级已更新至 ${newPriority}，生效层加载序已重新计算。`, 'success');
  };

  // External Change resolution
  const handleResolveDrift = (action: 'backup_and_overwrite' | 'abort' | 'force_overwrite') => {
    if (!driftOperation) return;

    if (action === 'backup_and_overwrite') {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === driftOperation.operation_id
            ? {
                ...op,
                status: 'in_progress',
                stage: 'writing',
                progress_percent: 85,
                failure_reason: undefined,
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 备份本地改动到 .submodhub_backups/drift_backup/ [OK]`,
                  `[${new Date().toLocaleTimeString()}] 恢复写入事务...`,
                ],
              }
            : op
        )
      );
      setDriftOperation(null);
      showToast('已备份外部修改文件，正在继续写入更新...', 'info');

      setTimeout(() => {
        setOperations((prev) =>
          prev.map((op) =>
            op.operation_id === driftOperation.operation_id
              ? {
                  ...op,
                  status: 'completed',
                  stage: 'committed',
                  progress_percent: 100,
                  log_lines: [
                    ...(op.log_lines || []),
                    `[${new Date().toLocaleTimeString()}] 事务提交完成 (COMMITTED)`,
                  ],
                }
              : op
          )
        );
        showToast('模组已恢复并成功更新！', 'success');
      }, 1500);
    } else if (action === 'abort') {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === driftOperation.operation_id
            ? {
                ...op,
                status: 'rolled_back',
                failure_reason: '用户选择保留外部改动并中止',
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 用户中止操作，完全保留本地改动文件，安全退出。`,
                ],
              }
            : op
        )
      );
      setDriftOperation(null);
      showToast('已取消本次更新，本地手动修改完整保留。', 'warn');
    } else {
      setOperations((prev) =>
        prev.map((op) =>
          op.operation_id === driftOperation.operation_id
            ? {
                ...op,
                status: 'completed',
                stage: 'committed',
                progress_percent: 100,
                failure_reason: undefined,
                log_lines: [
                  ...(op.log_lines || []),
                  `[${new Date().toLocaleTimeString()}] 强制覆盖本地改动为官方版本 [OK]`,
                ],
              }
            : op
        )
      );
      setDriftOperation(null);
      showToast('已强制以官方发布版本覆盖本地改动。', 'info');
    }
  };

  // Cold restart simulation
  const handleSimulateRestart = (operationId: string) => {
    showToast(`模拟应用冷重启：正在通过 operation_id [${operationId.slice(-8)}] 重建权威状态...`, 'info');
    setTimeout(() => {
      showToast('重连成功：会话状态已自本地 SQLite 完整还原。', 'success');
    }, 600);
  };

  // Export logs simulation
  const handleExportLogs = (operationId?: string) => {
    showToast('审计日志包已导出至 /sdcard/Download/submodhub_logs_20261003.zip', 'success');
  };

  // Restore snapshot backup
  const handleRestoreBackup = (backupName: string) => {
    showToast(`正在从备份快照 [${backupName}] 原子恢复游戏目录...`, 'info');
    setTimeout(() => {
      showToast(`已成功将游戏目录还原至快照点状态！`, 'success');
    }, 1000);
  };

  // Scenario quick preset handler
  const handleSelectScenario = (scenarioId: string) => {
    setCurrentScenario(scenarioId);
    if (scenarioId === 'normal') {
      setInstallations((prev) =>
        prev.map((i) =>
          i.id === 'inst_android_primary'
            ? { ...i, permission_state: 'granted', is_running: false }
            : i
        )
      );
      setOfflineMode(false);
      showToast('已切换至 [正常就绪] 状态。', 'success');
    } else if (scenarioId === 'permission_lost') {
      setInstallations((prev) =>
        prev.map((i) =>
          i.id === 'inst_android_primary'
            ? { ...i, permission_state: 'revoked' }
            : i
        )
      );
      setActiveTab('storage');
      showToast('已触发 [SAF 权限失效] 异常场景。', 'warn');
    } else if (scenarioId === 'game_running') {
      setInstallations((prev) =>
        prev.map((i) =>
          i.id === 'inst_android_primary' ? { ...i, is_running: true } : i
        )
      );
      setActiveTab('installed');
      showToast('已触发 [MAS 游戏正在运行] 保护场景。', 'warn');
    } else if (scenarioId === 'external_change') {
      setActiveTab('operations');
      const driftOp = operations.find((o) => o.status === 'recoverable') || operations[0];
      setDriftOperation(driftOp);
      showToast('已打开 [文件哈希漂移 external_change] 暂停拦截对话框。', 'warn');
    } else if (scenarioId === 'dependency_missing') {
      const conflictMod = mods.find((m) => m.id === 'mod_unstable_legacy');
      if (conflictMod) {
        setSelectedModForDetail(conflictMod);
        handleRequestPlan(conflictMod, conflictMod.latest_version_id);
        showToast('已生成 [版本不兼容与依赖缺失] 阻断安装计划预览。', 'warn');
      }
    } else if (scenarioId === 'offline') {
      setOfflineMode(true);
      setActiveTab('catalog');
      showToast('已切入 [离线本地缓存] 只读模式。', 'info');
    }
    setIsInspectorOpen(false);
  };

  const updatesCount = installedMods.filter((m) => m.has_update).length;
  const hasRunningOps = operations.some((o) => o.status === 'in_progress');
  const hasPermissionIssue = currentInstallation.permission_state !== 'granted';

  return (
    <AndroidFrame activeTab={activeTab}>
      {/* Top App Bar */}
      <TopAppBar
        currentInstallation={currentInstallation}
        onOpenInstancePicker={() => setIsInstancePickerOpen(true)}
        onOpenInspector={() => setIsInspectorOpen(true)}
        onRefreshCatalog={() => {
          setIsRefreshing(true);
          setTimeout(() => {
            setIsRefreshing(false);
            showToast('模组目录与本地索引已刷新至最新状态。', 'info');
          }, 600);
        }}
        isRefreshing={isRefreshing}
        offlineMode={offlineMode}
      />

      {/* Screen Body Viewport */}
      <main className="flex-1 relative overflow-hidden flex flex-col bg-slate-900">
        {activeTab === 'catalog' && (
          <CatalogTab
            mods={mods}
            currentInstallation={currentInstallation}
            onSelectMod={(mod) => setSelectedModForDetail(mod)}
            offlineMode={offlineMode}
          />
        )}

        {activeTab === 'installed' && (
          <InstalledTab
            installedMods={installedMods}
            currentInstallation={currentInstallation}
            allMods={mods}
            onSelectModById={(modId) => {
              const found = mods.find((m) => m.id === modId);
              if (found) setSelectedModForDetail(found);
            }}
            onRequestUpdatePlan={(modId) => {
              const found = mods.find((m) => m.id === modId);
              if (found) {
                const plan = generateSamplePlan(found, found.latest_version_id, currentInstallation);
                setActivePlan(plan);
              }
            }}
            onOpenAdoptModal={(unmanaged) => setUnmanagedToAdopt(unmanaged)}
            onOpenPriorityModal={(mod) => setModForPriority(mod)}
            onRequestUninstallPlan={(mod) => {
              showToast(`已生成卸载计划：将移除 ${mod.title} 并保留备份。`, 'info');
            }}
          />
        )}

        {activeTab === 'operations' && (
          <OperationsTab
            operations={operations}
            onOpenDriftModal={(op) => setDriftOperation(op)}
            onSimulateRestart={handleSimulateRestart}
            onExportLogs={handleExportLogs}
            onRetryOperation={(opId) => {
              showToast(`已重新启动操作 ID: ${opId}`, 'info');
            }}
          />
        )}

        {activeTab === 'storage' && (
          <StorageTab
            installations={installations}
            currentInstallationId={currentInstallationId}
            onSelectInstallation={(id) => setCurrentInstallationId(id)}
            onReauthorizeSaf={handleReauthorizeSaf}
            onDiscoverInstallations={handleDiscoverInstallations}
            onToggleGameRunning={handleToggleGameRunning}
            onRestoreBackup={handleRestoreBackup}
            onExportLogs={() => handleExportLogs()}
          />
        )}
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
        hasUpdatesCount={updatesCount}
        hasRunningOperations={hasRunningOps}
        hasPermissionIssue={hasPermissionIssue}
      />

      {/* Mod Detail Slide-up Modal */}
      {selectedModForDetail && (
        <ModDetailModal
          mod={selectedModForDetail}
          currentInstallation={currentInstallation}
          installedMods={installedMods}
          onClose={() => setSelectedModForDetail(null)}
          onRequestPlan={handleRequestPlan}
        />
      )}

      {/* Plan Preview Sheet (The Core Contract Verification Sheet) */}
      {activePlan && (
        <InstallPlanSheet
          plan={activePlan}
          installation={currentInstallation}
          onClose={() => setActivePlan(null)}
          onConfirmApply={handleConfirmApplyPlan}
        />
      )}

      {/* External Change / Drift Resolution Dialog */}
      {driftOperation && (
        <ExternalChangeModal
          operation={driftOperation}
          onClose={() => setDriftOperation(null)}
          onResolve={handleResolveDrift}
        />
      )}

      {/* Adopt Unmanaged Mod Dialog */}
      {unmanagedToAdopt && (
        <AdoptModal
          unmanagedMod={unmanagedToAdopt}
          onClose={() => setUnmanagedToAdopt(null)}
          onConfirmAdopt={handleConfirmAdopt}
        />
      )}

      {/* Priority Adjustment Preview Dialog */}
      {modForPriority && (
        <PriorityModal
          mod={modForPriority}
          allInstalledMods={installedMods}
          installation={currentInstallation}
          onClose={() => setModForPriority(null)}
          onApplyPriority={handleApplyPriority}
        />
      )}

      {/* Instance Picker Modal */}
      <InstancePickerModal
        isOpen={isInstancePickerOpen}
        installations={installations}
        currentInstallationId={currentInstallationId}
        onClose={() => setIsInstancePickerOpen(false)}
        onSelect={(id) => setCurrentInstallationId(id)}
        onDiscover={handleDiscoverInstallations}
        onReauthorize={handleReauthorizeSaf}
      />

      {/* Contract & Scenario Inspector */}
      <ContractInspector
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        currentScenario={currentScenario}
        onSelectScenario={handleSelectScenario}
      />

      {/* Toast Notification Alert */}
      {toast && (
        <div className="absolute top-16 left-4 right-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-medium border ${
              toast.type === 'success'
                ? 'bg-emerald-950/90 text-emerald-200 border-emerald-700/80 shadow-emerald-950/40'
                : toast.type === 'warn'
                ? 'bg-amber-950/90 text-amber-200 border-amber-700/80 shadow-amber-950/40'
                : 'bg-slate-800/90 text-slate-100 border-slate-700 shadow-slate-950/40'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : toast.type === 'warn' ? (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span className="flex-1 leading-snug">{toast.message}</span>
          </div>
        </div>
      )}
    </AndroidFrame>
  );
}
